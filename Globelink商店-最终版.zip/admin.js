﻿// ============================================================
//  Globelink商行 - 后台管理脚本（纯前端版）
// ============================================================

(function() {
  const catNames = { vpn: 'VPN加速', apple: '美区ID', charge: '代充服务', extra: '增值服务' };
  const payNames = { wechat: '微信', alipay: '支付宝', usdt: 'USDT' };

  function loadProducts() {
    let data = localStorage.getItem('gl_products');
    if (!data) {
      var defaults = [
        { id: 1, name: '手机加速器', category: 'vpn', price: 15, spec: '月付 15元/月', tags: ['教程','手机'], description: '手机端全球网络加速，稳定高速，附详细使用教程。', status: 'active' },
        { id: 2, name: '电脑不限速', category: 'vpn', price: 88, spec: '月付 88元/1000G', tags: ['教程','电脑','不限速'], description: '电脑端不限时高速加速，月流量1000G，适合重度用户。', status: 'active' },
        { id: 3, name: '季度VIP套餐', category: 'vpn', price: 198, spec: '手机+电脑 季度', tags: ['教程','套餐','优惠'], description: '手机+电脑双端加速，季度套餐更划算。', status: 'active' },
        { id: 4, name: '年度VIP', category: 'vpn', price: 698, spec: '全端不限速 年度', tags: ['教程','年度','超值'], description: '全年全端不限速，平均每月不到60元。', status: 'active' },
        { id: 5, name: '美区Apple ID（临时）', category: 'apple', price: 5, spec: '单次使用', tags: ['教程','临时'], description: '临时体验号，适合偶尔下载APP的用户。', status: 'active' },
        { id: 6, name: '美区Apple ID（永久）', category: 'apple', price: 58, spec: '独享绑定', tags: ['教程','永久','独享'], description: '永久独享账号，支持绑定个人信息，安全可靠。', status: 'active' },
        { id: 7, name: 'Apple家庭组', category: 'apple', price: 268, spec: '6人团 年度', tags: ['教程','家庭组'], description: '加入我们的Apple家庭组，共享付费应用和资源。', status: 'active' },
        { id: 8, name: 'GPT Plus 会员', category: 'charge', price: 35, spec: '月付', tags: ['代充','秒到'], description: 'ChatGPT Plus月卡代充，官方账号，安全可靠。', status: 'active' },
        { id: 9, name: 'Claude Pro', category: 'charge', price: 40, spec: '月付', tags: ['代充','秒到'], description: 'Anthropic Claude Pro月度会员代充。', status: 'active' },
        { id: 10, name: 'Midjourney', category: 'charge', price: 30, spec: '月付', tags: ['代充','AI绘画'], description: 'MJ月度会员代充，支持各种AI绘画需求。', status: 'active' },
        { id: 11, name: '远程配置服务', category: 'extra', price: 8, spec: '一对一指导', tags: ['远程','教程'], description: '一对一远程协助，帮您配置各种软件和服务。', status: 'active' },
        { id: 12, name: '其他国外软件代充', category: 'charge', price: 20, spec: '按需报价', tags: ['代充','咨询'], description: '除以上列出的软件外，其他国外软件也可代充，请联系客服询价。', status: 'active' },
      ];
      localStorage.setItem('gl_products', JSON.stringify(defaults));
      return defaults;
    }
    return JSON.parse(data);
  }

  function saveProducts(products) {
    localStorage.setItem('gl_products', JSON.stringify(products));
  }

  function loadOrders() {
    return JSON.parse(localStorage.getItem('gl_orders') || '[]');
  }

  function saveOrders(orders) {
    localStorage.setItem('gl_orders', JSON.stringify(orders));
  }

  function loadSettings() {
    var data = localStorage.getItem('gl_settings');
    return data ? JSON.parse(data) : {
      wechat: 'globelink_support', qq: '123456789', usdt: '',
      banner_title: '全球网络加速 · 一站式数字服务',
      banner_sub: 'VPN加速 | 美区Apple ID | 国外软件代充 | 远程配置指导'
    };
  }

  function saveSettings(s) { localStorage.setItem('gl_settings', JSON.stringify(s)); }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function renderProductsTable() {
    var products = loadProducts();
    var tbody = document.getElementById('products-table-body');
    tbody.innerHTML = products.map(function(p) {
      var sc = p.status === 'active' ? 'status-active' : 'status-inactive';
      var st = p.status === 'active' ? '上架' : '下架';
      return '<tr>' +
        '<td>' + p.id + '</td><td>' + escapeHtml(p.name) + '</td>' +
        '<td>' + (catNames[p.category] || p.category) + '</td>' +
        '<td>¥' + p.price + '</td>' +
        '<td class="' + sc + '">' + st + '</td>' +
        '<td>' +
          '<button class="btn-sm btn-edit" onclick="editProduct(' + p.id + ')">编辑</button>' +
          '<button class="btn-sm btn-toggle" onclick="toggleProduct(' + p.id + ')">' + (p.status === 'active' ? '下架' : '上架') + '</button>' +
          '<button class="btn-sm btn-delete" onclick="deleteProduct(' + p.id + ')">删除</button>' +
        '</td></tr>';
    }).join('');
  }

  function renderOrdersTable() {
    var orders = loadOrders();
    var tbody = document.getElementById('orders-table-body');
    if (orders.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#8892b0;padding:40px;">暂无订单</td></tr>';
      return;
    }
    tbody.innerHTML = orders.map(function(o) {
      var sc = 'status-' + o.status;
      var st = { pending: '待处理', completed: '已完成', cancelled: '已取消' }[o.status] || o.status;
      return '<tr>' +
        '<td style="font-size:11px;">' + escapeHtml(o.id) + '</td>' +
        '<td>' + escapeHtml(o.product_name) + '</td>' +
        '<td>' + escapeHtml(o.customer_name) + '</td>' +
        '<td>' + escapeHtml(o.contact) + '</td>' +
        '<td>' + (payNames[o.payment] || o.payment) + '</td>' +
        '<td>¥' + o.price + '</td>' +
        '<td class="' + sc + '">' + st + '</td>' +
        '<td>' +
          '<button class="btn-sm btn-toggle" onclick="completeOrder(\'' + escapeAttr(o.id) + '\')">完成</button>' +
          '<button class="btn-sm btn-delete" onclick="cancelOrder(\'' + escapeAttr(o.id) + '\')">取消</button>' +
        '</td></tr>';
    }).join('');
  }

  function escapeAttr(str) {
    return String(str).replace(/'/g, "\\'").replace(/\\/g, '\\\\');
  }

  // Tab
  document.querySelectorAll('.sidebar-menu li').forEach(function(li) {
    li.addEventListener('click', function() {
      document.querySelectorAll('.sidebar-menu li').forEach(function(l) { l.classList.remove('active'); });
      li.classList.add('active');
      document.querySelectorAll('.tab-content').forEach(function(tc) { tc.classList.remove('active'); });
      document.getElementById('tab-' + li.dataset.tab).classList.add('active');
    });
  });

  window.openProductForm = function(id) {
    document.getElementById('product-modal').classList.add('show');
    var products = loadProducts();
    if (id) {
      var p = products.find(function(x) { return x.id === id; });
      if (p) {
        document.getElementById('product-modal-title').textContent = '编辑商品';
        document.getElementById('prod-edit-id').value = p.id;
        document.getElementById('prod-name').value = p.name;
        document.getElementById('prod-category').value = p.category;
        document.getElementById('prod-price').value = p.price;
        document.getElementById('prod-spec').value = p.spec || '';
        document.getElementById('prod-tags').value = Array.isArray(p.tags) ? p.tags.join(',') : '';
        document.getElementById('prod-desc').value = p.description || '';
        document.getElementById('prod-status').value = p.status;
      }
    } else {
      document.getElementById('product-modal-title').textContent = '添加商品';
      document.getElementById('prod-edit-id').value = '';
      document.getElementById('product-form').reset();
    }
  };

  window.closeProductModal = function() {
    document.getElementById('product-modal').classList.remove('show');
  };

  document.getElementById('product-form').addEventListener('submit', function(e) {
    e.preventDefault();
    var products = loadProducts();
    var editId = document.getElementById('prod-edit-id').value;
    var tags = document.getElementById('prod-tags').value.split(',').map(function(t){return t.trim();}).filter(function(t){return t;});
    var data = {
      name: document.getElementById('prod-name').value,
      category: document.getElementById('prod-category').value,
      price: parseFloat(document.getElementById('prod-price').value),
      spec: document.getElementById('prod-spec').value,
      tags: tags,
      description: document.getElementById('prod-desc').value,
      status: document.getElementById('prod-status').value
    };
    if (editId) {
      var idx = products.findIndex(function(p){return p.id==editId;});
      if(idx>-1) Object.assign(products[idx], data);
    } else {
      var maxId = products.reduce(function(m,p){return Math.max(m,p.id);},0);
      data.id = maxId + 1;
      products.push(data);
    }
    saveProducts(products);
    renderProductsTable();
    closeProductModal();
    alert(editId ? '商品已更新' : '商品已添加');
  });

  window.editProduct = function(id) { window.openProductForm(id); };
  window.toggleProduct = function(id) {
    var products = loadProducts();
    var p = products.find(function(x){return x.id===id;});
    if(p){p.status=p.status==='active'?'inactive':'active';saveProducts(products);}
    renderProductsTable();
  };
  window.deleteProduct = function(id) {
    if(!confirm('确定删除？'))return;
    saveProducts(loadProducts().filter(function(p){return p.id!==id;}));
    renderProductsTable();
  };

  window.completeOrder = function(oid) {
    var orders = loadOrders();
    var o = orders.find(function(x){return x.id===oid;});
    if(o)o.status='completed';
    saveOrders(orders);renderOrdersTable();
  };
  window.cancelOrder = function(oid) {
    var orders = loadOrders();
    var o = orders.find(function(x){return x.id===oid;});
    if(o)o.status='cancelled';
    saveOrders(orders);renderOrdersTable();
  };

  window.exportOrders = function() {
    var orders = loadOrders();
    if(!orders.length){alert('暂无订单');return;}
    var csv='\uFEFF订单号,商品,客户,联系方式,支付,金额,状态,时间\r\n';
    orders.forEach(function(o){
      csv+=o.id+','+o.product_name+','+o.customer_name+','+o.contact+','+(payNames[o.payment]||o.payment)+','+o.price+','+o.status+','+o.created_at+'\r\n';
    });
    var blob=new Blob([csv],{type:'text/csv'});
    var a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download='orders_'+new Date().toISOString().slice(0,10)+'.csv';
    a.click();
  };

  // 加载设置
  var s = loadSettings();
  if(s.wechat)document.getElementById('setting-wechat').value=s.wechat;
  if(s.qq)document.getElementById('setting-qq').value=s.qq;
  if(s.usdt)document.getElementById('setting-usdt').value=s.usdt;
  if(s.banner_title)document.getElementById('setting-banner-title').value=s.banner_title;
  if(s.banner_sub)document.getElementById('setting-banner-sub').value=s.banner_sub;

  window.saveSettings = function() {
    var s = {
      wechat: document.getElementById('setting-wechat').value,
      qq: document.getElementById('setting-qq').value,
      usdt: document.getElementById('setting-usdt').value,
      banner_title: document.getElementById('setting-banner-title').value,
      banner_sub: document.getElementById('setting-banner-sub').value,
    };
    saveSettings(s);
    alert('设置已保存');
  };

  renderProductsTable();
  renderOrdersTable();
})();
