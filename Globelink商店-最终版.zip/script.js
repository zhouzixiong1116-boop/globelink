﻿// ============================================================
//  Globelink商行 - 前台脚本（纯前端版，适配 Netlify/Vercel）
// ============================================================

(function() {
  const catNames = { vpn: 'VPN加速', apple: '美区ID', charge: '代充服务', extra: '增值服务' };
  const catIcons = { vpn: '🌐', apple: '🍎', charge: '⚡', extra: '🛠' };

  function loadProducts() {
    let data = localStorage.getItem('gl_products');
    if (!data) {
      const defaults = [
        { id: 1, name: '手机加速器', category: 'vpn', price: 15, spec: '月付 15元/月', tags: ['教程','手机'], description: '手机端全球网络加速，稳定高速，附详细使用教程。', status: 'active' },
        { id: 2, name: '电脑不限速', category: 'vpn', price: 88, spec: '月付 88元/1000G', tags: ['教程','电脑','不限速'], description: '电脑端不限时高速加速，月流量1000G，适合重度用户。', status: 'active' },
        { id: 3, name: '季度VIP套餐', category: 'vpn', price: 198, spec: '手机+电脑 季度', tags: ['教程','套餐','优惠'], description: '手机+电脑双端加速，季度套餐更划算。', status: 'active' },
        { id: 4, name: '年度VIP', category: 'vpn', price: 698, spec: '全端不限速 年度', tags: ['教程','年度','超值'], description: '全年全端不限速，平均每月不到60元。', status: 'active' },
        { id: 5, name: '美区Apple ID（临时）', category: 'apple', price: 5, spec: '单次使用', tags: ['教程','临时'], description: '临时体验号，适合偶尔下载APP的用户。', status: 'active' },
        { id: 6, name: '美区Apple ID（永久）', category: 'apple', price: 58, spec: '独享绑定', tags: ['教程','永久','独享'], description: '永久独享账号，支持绑定个人信息，安全可靠。', status: 'active' },
        { id: 7, name: 'Apple家庭组', category: 'apple', price: 268, spec: '6人团 年度', tags: ['教程','家庭组'], description: '加入我们的Apple家庭组，共享付费应用和资源。', status: 'active' },
        { id: 8, name: 'GPT Plus 会员', category: 'charge', price: 35, spec: '月付', tags: ['代充','秒到'], description: 'ChatGPT Plus月卡代充，官方账号，安全可靠。', status: 'active' },
        { id: 9, name: 'Claude Pro', category: 'charge', price: 40, spec: '月付', tags: ['代充','秒到'], description: 'Anthropic Claude Pro月度会员代充。', status: 'active' },
        { id: 10, name: 'Midjourney', category: 'charge', price: 30, spec: '月付', tags: ['代充','AI绘画'], description: 'MJ月度会员代充，支持各种AI绘画需求。', status: 'active' },
        { id: 11, name: '远程配置服务', category: 'extra', price: 8, spec: '一对一指导', tags: ['远程','教程'], description: '一对一远程协助，帮您配置各种软件和服务。', status: 'active' },
        { id: 12, name: '其他国外软件代充', category: 'charge', price: 20, spec: '按需报价', tags: ['代充','咨询'], description: '除以上列出的软件外，其他国外软件也可代充，请联系客服询价。', status: 'active' },
      ];
      localStorage.setItem('gl_products', JSON.stringify(defaults));
      return defaults;
    }
    return JSON.parse(data);
  }

  function getSettings() {
    const data = localStorage.getItem('gl_settings');
    return data ? JSON.parse(data) : {
      wechat: 'globelink_support',
      qq: '123456789',
      usdt: '',
      banner_title: '全球网络加速 · 一站式数字服务',
      banner_sub: 'VPN加速 | 美区Apple ID | 国外软件代充 | 远程配置指导'
    };
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function escapeAttr(str) {
    return String(str).replace(/'/g, "\\'").replace(/\\/g, '\\\\');
  }

  function renderProducts(filterCat) {
    const products = loadProducts().filter(function(p) { return p.status === 'active'; });
    const filtered = filterCat === 'all' ? products : products.filter(function(p) { return p.category === filterCat; });
    const container = document.getElementById('products-grid');
    if (!container) return;

    if (filtered.length === 0) {
      container.innerHTML = '<p style="text-align:center;color:#8892b0;grid-column:1/-1;padding:60px 0;">暂无商品</p>';
      return;
    }

    container.innerHTML = filtered.map(function(p) {
      var tags = p.tags || [];
      var tagsHtml = tags.map(function(t) { return '<span class="product-tag">' + escapeHtml(t) + '</span>'; }).join('');
      return '<div class="product-card">' +
        '<div class="product-cat">' + (catIcons[p.category] || '') + ' ' + (catNames[p.category] || p.category) + '</div>' +
        '<div class="product-name">' + escapeHtml(p.name) + '</div>' +
        '<div class="product-spec">' + escapeHtml(p.spec) + '</div>' +
        '<div class="product-tags">' + tagsHtml + '</div>' +
        '<div class="product-price">¥' + p.price + '<span></span></div>' +
        (p.description ? '<div class="product-desc">' + escapeHtml(p.description) + '</div>' : '') +
        '<button class="btn-order" onclick="window.openOrder(' + p.id + ',\'' + escapeAttr(p.name) + '\',' + p.price + ')">立即下单</button>' +
        '</div>';
    }).join('');
  }

  window.openOrder = function(productId, productName, price) {
    var settings = getSettings();
    document.getElementById('order-product-info').innerHTML =
      '<h3>' + escapeHtml(productName) + '</h3>' +
      '<div class="price">¥' + price + '</div>';

    document.getElementById('order-modal').classList.add('show');
    document.getElementById('order-form').onsubmit = function(e) {
      e.preventDefault();
      var name = document.getElementById('order-name').value;
      var contact = document.getElementById('order-contact').value;
      var payment = document.getElementById('order-payment').value;
      var note = document.getElementById('order-note').value;

      // 保存到本地
      var orders = JSON.parse(localStorage.getItem('gl_orders') || '[]');
      var orderId = 'GL' + Date.now();
      orders.unshift({
        id: orderId,
        product_id: productId,
        product_name: productName,
        price: price,
        customer_name: name,
        contact: contact,
        payment: payment,
        note: note,
        status: 'pending',
        created_at: new Date().toLocaleString('zh-CN')
      });
      localStorage.setItem('gl_orders', JSON.stringify(orders));

      // 弹出客服信息
      var msg = '✅ 订单已提交！订单号：' + orderId + '\n\n';
      msg += '请按以下方式联系客服完成支付：\n';
      msg += '💬 微信: ' + settings.wechat + '\n';
      msg += '💬 QQ: ' + settings.qq;
      if (settings.usdt) msg += '\n💰 USDT: ' + settings.usdt;
      msg += '\n\n付款后发送订单号给客服即可！';

      alert(msg);
      closeModal();
      document.getElementById('order-form').reset();
    };
  };

  window.closeModal = function() {
    document.getElementById('order-modal').classList.remove('show');
  };

  document.querySelectorAll('.filter-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('.filter-btn').forEach(function(b) { b.classList.remove('active'); });
      btn.classList.add('active');
      renderProducts(btn.dataset.cat);
    });
  });

  renderProducts('all');
})();
